/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package appli;

import entities.Livre;
import java.util.ArrayList;
//import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Damien
 */
public class AppTest {

    public AppTest() {
    }

    /**
     * Test of runBibliothequeIHM method, of class App.
     */
    @Test
    public void testRunBibliothequeIHM() {
        System.out.println("runBibliothequeIHM");
        App instance = new App();
        instance.runBibliothequeIHM();
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
        /*Assertions.*/assertEquals("Hello", "Hi", "What the fuck ?!");
    }

    /**
     * Test of majBiblio method, of class App.
     */
    @Test
    public void testMajBiblio() {
        System.out.println("majBiblio");
        App instance = new App();
        instance.majBiblio();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setRowCountjTableBiblio method, of class App.
     */
    @Test
    public void testSetRowCountjTableBiblio() {
        System.out.println("setRowCountjTableBiblio");
        int rowCount = 0;
        App instance = new App();
        instance.setRowCountjTableBiblio(rowCount);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of afficherListejTableBiblio method, of class App.
     */
    @Test
    public void testAfficherListejTableBiblio_0args() {
        System.out.println("afficherListejTableBiblio");
        App instance = new App();
        instance.afficherListejTableBiblio();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of afficherListejTableBiblio method, of class App.
     */
    @Test
    public void testAfficherListejTableBiblio_ArrayList() {
        System.out.println("afficherListejTableBiblio");
        ArrayList<Livre> list = null;
        App instance = new App();
        instance.afficherListejTableBiblio(list);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of main method, of class App.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        App.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of jFrameBiblioBoutonAnnuler method, of class App.
     */
    @Test
    public void testJFrameBiblioBoutonAnnuler() {
        System.out.println("jFrameBiblioBoutonAnnuler");
        App instance = new App();
        instance.jFrameBiblioBoutonAnnuler();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

}
