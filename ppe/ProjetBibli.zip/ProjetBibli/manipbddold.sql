-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  Dim 24 oct. 2021 à 15:12
-- Version du serveur :  5.7.26
-- Version de PHP :  7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `manipbddold`
--

-- --------------------------------------------------------

--
-- Structure de la table `livres`
--

DROP TABLE IF EXISTS `livres`;
CREATE TABLE IF NOT EXISTS `livres` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `Titre` varchar(100) NOT NULL,
  `Auteur` varchar(50) NOT NULL,
  `Ref` int(10) UNSIGNED NOT NULL,
  `NbrPages` smallint(5) UNSIGNED NOT NULL,
  `edition` varchar(100) NOT NULL,
  `genre` varchar(100) NOT NULL,
  `anneeEdition` smallint(6) NOT NULL,
  `langue` varchar(50) NOT NULL,
  `format` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `livres`
--

INSERT INTO `livres` (`id`, `Titre`, `Auteur`, `Ref`, `NbrPages`, `edition`, `genre`, `anneeEdition`, `langue`, `format`) VALUES
(1, 'Prométhée Moderne', 'Shelley', 111, 300, 'Plon', 'Roman', 1886, 'Français', 'poche'),
(4, 'Hello', 'Truc', 524, 958, 'Plon', 'Romin', 1589, 'Copte', 'pochette'),
(5, 'I am legend', 'Toto', 111, 254, 'Plon', 'Licre', 1986, 'French', 'kiki');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
